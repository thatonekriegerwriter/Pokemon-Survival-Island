#=================================================================================
This is an expansion of the Gen 8 Project for Pokémon Essentials 
v19.1 that adds content from Pokémon Legends: Arceus, which includes the
game's exclusive Pokémon, moves, items, and a few mechanics.

All credits go to StCooler who first created this script for v18. Credits
also go to curryofthepast who adapted major portions of the code for
future releases.

TO DO: -Pokemon Back sprites
       -Adamant Crystal icon
       -Lustrous Globe icon
       -Following pokemon shinies
       -Pokemon shiny icons
#=================================================================================

In order to install the features of this expansion into your game, please
follow these instructions carefully and closely:

1) Make a backup of your game to recover it in the event of a mishap or
   to save any content beforehand that might get erased during installation
   (which should not happen script-wise).

2) Drag the contents of Audio/SE/Cries into your game's respective folder.

   NOTE: There are two cries of Pikachu and Eevee that match the ones in
	 Pokémon Legends: Arceus. Do not drag these if and only if you
	 DON'T want previous cries of these Pokémon to be overwritten.

3) Drag the contents of the Graphics folder into their respective places.

  NOTE: Only drag the files that you want to overwrite previous graphics,
	skip the contents if you have graphics you want to keep.

4) Copy and paste the contents inside items.txt in the PBS folder into
   your game's items.txt.

  NOTE: The ID numbers have been replaced with "XXX". Change this to
	the next avaliable ID slot. Ex: XXX > 801

5) Copy and paste the contents inside moves.txt in the PBS folder into
   your game's moves.txt.

  NOTE: The ID numbers have been replaced with "XXX". Change this to
	the next avaliable ID slot. Ex: XXX > 801

6) Copy and paste the contents inside pokemon.txt in the PBS folder into
   your game's pokemon.txt.

  NOTE: The ID numbers have been replaced with "[X]". Change this to
	the next avaliable ID slot. Ex: [X] > [899] for Wyrdeer

7) Copy and paste the contents inside pokemonforms.txt in the PBS folder
   into your game's pokemonforms.txt.

  NOTE: This method requires more caution than the previous steps, as you
	should insert data into their correct spots by Pokédex order

8) There is a file called "pokemonchanges (Optional).txt" that has
   updated data for Stantler, Scyther, and Ursaring to fit with the
   expansion. If you don't want to overwrite the existing data for these
   Pokémon, skip to step 9. Otherwise, replace the existing data with the
   contents of pokemonchanges (Optional).txt.

9) Drag the contents of the Plugins folder into your game's respective
   folder.

10) Last and the hardest part of the installation, open your game and
   follow the instuctions in Script Changes.txt CAREFULLY and CAUTIOUSLY.